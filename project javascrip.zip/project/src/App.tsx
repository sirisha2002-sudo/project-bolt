import React from 'react';
import { UserPlus } from 'lucide-react';
import { UserTable } from './components/UserTable';
import { UserModal } from './components/UserModal';
import type { User, UserFormData, UserModalMode } from './types';

const API_URL = 'https://jsonplaceholder.typicode.com/users';

function App() {
  const [users, setUsers] = React.useState<User[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [modalMode, setModalMode] = React.useState<UserModalMode>(null);
  const [selectedUser, setSelectedUser] = React.useState<User | undefined>();

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const response = await fetch(API_URL);
      if (!response.ok) throw new Error('Failed to fetch users');
      const data = await response.json();
      
      // Transform the data to match our schema
      const transformedUsers = data.map((user: any) => ({
        id: user.id,
        firstName: user.name.split(' ')[0],
        lastName: user.name.split(' ')[1] || '',
        email: user.email,
        department: user.company.name,
        likes: 0,
        isLiked: false,
      }));
      
      setUsers(transformedUsers);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchUsers();
  }, []);

  const handleAddUser = async (data: UserFormData) => {
    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
          'Content-type': 'application/json',
        },
      });
      
      if (!response.ok) throw new Error('Failed to add user');
      
      // Since JSONPlaceholder doesn't actually add the user,
      // we'll simulate it by adding it to our local state
      const newUser = {
        ...data,
        id: users.length + 1,
        likes: 0,
        isLiked: false,
      };
      
      setUsers([...users, newUser]);
      setModalMode(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add user');
    }
  };

  const handleEditUser = async (data: UserFormData) => {
    if (!selectedUser) return;
    
    try {
      const response = await fetch(`${API_URL}/${selectedUser.id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
        headers: {
          'Content-type': 'application/json',
        },
      });
      
      if (!response.ok) throw new Error('Failed to update user');
      
      // Update local state
      const updatedUsers = users.map((user) =>
        user.id === selectedUser.id ? { ...user, ...data } : user
      );
      
      setUsers(updatedUsers);
      setModalMode(null);
      setSelectedUser(undefined);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update user');
    }
  };

  const handleDeleteUser = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    
    try {
      const response = await fetch(`${API_URL}/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) throw new Error('Failed to delete user');
      
      // Update local state
      setUsers(users.filter((user) => user.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete user');
    }
  };

  const handleLikeUser = async (id: number) => {
    try {
      // Simulate API call (in a real app, you'd make an actual API request)
      const updatedUsers = users.map((user) => {
        if (user.id === id) {
          return {
            ...user,
            likes: user.isLiked ? user.likes - 1 : user.likes + 1,
            isLiked: !user.isLiked,
          };
        }
        return user;
      });
      
      setUsers(updatedUsers);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update like');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-xl font-semibold text-gray-600">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <div className="sm:flex sm:items-center">
              <div className="sm:flex-auto">
                <h1 className="text-2xl font-semibold text-gray-900">Users</h1>
                <p className="mt-2 text-sm text-gray-700">
                  A list of all users in the system including their name, email, and department.
                </p>
              </div>
              <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
                <button
                  onClick={() => setModalMode('add')}
                  className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add User
                </button>
              </div>
            </div>

            {error && (
              <div className="mt-4 bg-red-50 border border-red-200 rounded-md p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-red-800">{error}</h3>
                  </div>
                  <div className="ml-auto pl-3">
                    <div className="-mx-1.5 -my-1.5">
                      <button
                        onClick={() => setError(null)}
                        className="inline-flex rounded-md p-1.5 text-red-500 hover:bg-red-100"
                      >
                        <span className="sr-only">Dismiss</span>
                        <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-8">
              <UserTable
                users={users}
                onEdit={(user) => {
                  setSelectedUser(user);
                  setModalMode('edit');
                }}
                onDelete={handleDeleteUser}
                onLike={handleLikeUser}
              />
            </div>
          </div>
        </div>
      </div>

      <UserModal
        isOpen={modalMode !== null}
        mode={modalMode}
        user={selectedUser}
        onClose={() => {
          setModalMode(null);
          setSelectedUser(undefined);
        }}
        onSubmit={(data) => {
          if (modalMode === 'add') {
            handleAddUser(data);
          } else {
            handleEditUser(data);
          }
        }}
      />
    </div>
  );
}

export default App;